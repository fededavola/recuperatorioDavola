import { StatusBar } from 'expo-status-bar';
import React, {Component} from 'react';
import { StyleSheet, Text, View, Image, Button, Alert, ScrollView, FlatList } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { TouchableOpacity } from 'react-native-gesture-handler';



export default class Screen_2 extends Component {
    constructor(){
        super();
        this.state = {
            personajes: [],
            personajesGuardados: [],

        }
    }

    async getData(){
        try{
    const resultado= await AsyncStorage.getItem('Personajes')
    this.setState({personajesGuardados: JSON.parse(resultado)})
    console.log('llego el personaje')

        }
        catch(e){
            console.log(e)
        }
    }
 async formatoArray(){
    const jsonStringify= JSON.stringify(this.state.personajesGuardados)
    await AsyncStorage.setItem('Personajes', jsonStringify);


 }

renderItem({item}){
 return (
    <View key={item.id} style={{backgroundColor: '#87cefa', borderWidth: 5, margin: 2}}>
    <Image source={{uri:item.image}} style={{width: 100, height: 100, }}/>
    <Text>
        Name: {item.name}
    </Text>
    <Text>
        Species: {item.species}
    </Text>
    <Text>
        Status: {item.status}
    </Text>
    


</View>

 )
}

    render(){
        const values = this.state.personajesGuardados.map( item =>
            <View key={item.id} style={{backgroundColor: '#87cefa', borderWidth: 5, margin: 2}}>
                <Image source={{uri:item.image}} style={{width: 100, height: 100, }}/>
                <Text>
                    Name: {item.name}
                </Text>
                <Text>
                    Species: {item.species}
                </Text>
                <Text>
                    Status: {item.status}
                </Text>
                


            </View>
        )
        
  return (
    <View style={styles.container}>
      <TouchableOpacity style={{marginTop: 60,  }} onPress={()=> this.getData()}>
    <Text style={{alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 'bold' }}>Presiona para importar personajes</Text>
    </TouchableOpacity>
    <FlatList 
           data={this.state.personajesGuardados}
           renderItem={this.renderItem}
           keyExtractor={(item, idx)=>idx.toString()}
           />
           
          
    </View>
  );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    flexWrap:'wrap',
  },
});
