import { StatusBar } from 'expo-status-bar';
import React, {Component} from 'react';
import { StyleSheet, Text, View, Image, Button, Alert, Animated, FlatList, } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { TouchableOpacity } from 'react-native-gesture-handler';



export default class Screen_1 extends Component {
    constructor(){
        super();
        this.state ={
            personajes: [],
            personajesGuardados:[],
            id: 1,




        }
    }
 componentDidMount(){
    this.importarDatos();
}

componentDidUpdate(){
 
}
    importarDatos(){
        fetch('https://rickandmortyapi.com/api/character/' + this.state.id)
        .then(response=> response.json())
        .then((result)=>{
          
          this.setState({personajes: result})
        })
       }

       async storeData(){
        try{
         const resultado= await AsyncStorage.getItem('Personajes')
         const JsonObjeto = JSON.parse(resultado)
            let array = JsonObjeto ? JsonObjeto : []
            array.push(this.state.personajes)
    const jsonStringify= JSON.stringify(array)
    await AsyncStorage.setItem('Personajes', jsonStringify);
    this.setState({id : this.state.id + 1})
    this.importarDatos()
    

    console.log("Se guardo el personaje")
    Alert.alert("Se guardo el personaje")
      }
      catch(e){
  console.log(e)
      }
    }

    descartarPersonaje(info){
        this.setState({id : this.state.id + 1})
        this.importarDatos()

   
        }

        topDown= (info)=>{
            Animated.sequence([
             Animated.spring(this.rotation,{
               toValue: 15,
               duration: 100,
               useNativeDriver: false
             }),
             Animated.spring(this.rotation,{
               toValue: 0,
               duration: 100,
               useNativeDriver: false
             })
         
            ]).start();
          
           this.state.personajesGuardados.push(info)
          this.setState({personajesGuardados: this.state.personajesGuardados})
         }

         

    render(item){
        
        const values =
            <View key={this.state.personajes.id} style={{backgroundColor: '#87cefa', borderWidth: 5, margin: 2}}>
                <Image source={{uri:this.state.personajes.image}} style={{width: 100, height: 100, }}/>
                <Text>
                    Name: {this.state.personajes.name}
                </Text>
                <Text>
                    Species: {this.state.personajes.species}
                </Text>
                <Text>
                    Status: {this.state.personajes.status}
                </Text>
                <Button title= 'guardar personaje' onPress={()=> this.storeData()}></Button>
                <Button title= 'descartar personaje' onPress={()=> this.descartarPersonaje()}></Button>


            </View>
            
  return (
    <View style={styles.container}>
        
        {values}
        
    </View>
  );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
