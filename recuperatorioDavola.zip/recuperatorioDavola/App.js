import { StatusBar } from 'expo-status-bar';
import React, {Component} from 'react';
import { StyleSheet, Text, View } from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createDrawerNavigator} from '@react-navigation/drawer';
import 'react-native-gesture-handler';
import Screen_1 from './Screens/Screen_1';
import Screen_2 from './Screens/Screen_2';



const Drawer = createDrawerNavigator();


export default class App extends Component {
render(){
  return (
    <NavigationContainer>
      <Drawer.Navigator>
        <Drawer.Screen name= 'Importación de personajes' component={Screen_1}/>
        <Drawer.Screen name= 'Personajed Importados' component={Screen_2}/>
    </Drawer.Navigator>
    </NavigationContainer>
  );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
